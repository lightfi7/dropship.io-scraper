#!/bin/bash

npm i
node main.js